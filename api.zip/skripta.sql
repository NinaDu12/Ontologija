create database nduvnjak_19 default character set utf8;
use nduvnjak_19;
create table ontologija_glumci(
    sifra int not null primary key auto_increment,
    glumac varchar(100) not null,
    nagrada varchar(100) not null,
    rodjenje varchar(100) not null,
    zavrsio varchar(100) not null,
    glumi varchar(100) not null,
    godina int not null,
    imaUloga int not null
);
