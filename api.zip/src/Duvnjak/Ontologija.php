<?php

namespace Duvnjak;

/**
 * @Entity @Table(name="ontologija_glumci")
 **/


class Ontologija
{
    /** @id @Column(type="integer") @GeneratedValue **/
    protected $sifra;

    /**
    * @Column(type="string")
    */
    private $glumac;

    /**
    * @Column(type="string")
    */
    private $glumi;

    /**
    * @Column(type="string")
    */
    private $nagrada;

    /**
    * @Column(type="string")
    */
    private $rodjenje;

    /**
    * @Column(type="string")
    */
    private $zavrsio;

    /**
    * @Column(type="integer")
    */
    private $godina;

    /**
    * @Column(type="integer")
    */
    private $imaUloga;

  public function getSifra(){
		return $this->sifra;
	}

	public function setSifra($sifra){
		$this->sifra = $sifra;
	}

  public function getGlumac(){
		return $this->glumac;
	}

	public function setGlumac($glumac){
		$this->glumac = $glumac;
	}

  public function getGlumi(){
    return $this->glumi;
  }

  public function setGlumi($glumi){
		$this->glumi = $glumi;
	}

  public function getNagrada(){
  	return $this->nagrada;
  }

  public function setNagrada($nagrada){
		$this->nagrada = $nagrada;
	}

  public function getRodjenje(){
    return $this->rodjenje;
  }

  public function setRodjenje($rodjenje){
    $this->rodjenje = $rodjenje;
  }

  public function getZavrsio(){
    return $this->zavrsio;
  }

  public function setZavrsio($zavrsio){
    $this->zavrsio = $zavrsio;
  }

  public function getGodina(){
    return $this->godina;
  }

  public function setGodina($godina){
    $this->godina = $godina;
  }

  public function getImaUloga(){
    return $this->imaUloga;
  }

  public function setImaUloga($imaUloga){
    $this->imaUloga = $imaUloga;
  }

  public function setPodaci($podaci)
	{
		foreach($podaci as $kljuc => $vrijednost){
			$this->{$kljuc} = $vrijednost;
		}
	}

}

?>
