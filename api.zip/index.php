<?php
require 'vendor/autoload.php';
require 'bootstrap.php';
use Duvnjak\Ontologija;
use Composer\Autoload\ClassLoader;

Flight::route('GET /search', function(){

  $doctrineBootstrap = Flight::entityManager();
  $em = $doctrineBootstrap->getEntityManager();
  $repozitorij=$em->getRepository('Duvnjak\Ontologija');
  $zapisi = $repozitorij->findAll();
  echo $doctrineBootstrap->getJson($zapisi);
});

Flight::route('GET /baza', function(){

  $foaf = \EasyRdf\Graph::newAndLoad('http://oziz.ffos.hr/nastava20192020/nduvnjak_19/ontologija/rdf/simple_duvnjak_finalna.rdf');

  foreach ($foaf->resources() as $resource) {

    $glumi = $foaf->get($resource, '<http://oziz.ffos.hr/nduvnjak/se-ontologije#glumiU>');
    $nagrada = $foaf->get($resource, '<http://oziz.ffos.hr/nduvnjak/se-ontologije#JeDobioNagradu>');
    $rodjenje = $foaf->get($resource, '<http://oziz.ffos.hr/nduvnjak/se-ontologije#JeRodjenU>');
    $zavrsio = $foaf->get($resource, '<http://oziz.ffos.hr/nduvnjak/se-ontologije#JeZavrsio>');
    $godina = ''.$foaf->get($resource, '<http://oziz.ffos.hr/nduvnjak/se-ontologije#imaGodina>');
    $uloga = ''.$foaf->get($resource, '<http://oziz.ffos.hr/nduvnjak/se-ontologije#imaUloga>');

    if($glumi != ''){

      $url = parse_url($resource);
      $glumac = $url["fragment"];

      $url = parse_url($glumi);
      $glumi = $url["fragment"];

      $url = parse_url($nagrada);
      $nagrada = $url["fragment"];


      $url = parse_url($rodjenje);
      $rodjenje = $url["fragment"];


      $url = parse_url($zavrsio);
      $zavrsio = $url["fragment"];

    $ontologija = new Ontologija();
    $ontologija->setPodaci(Flight::request()->data);

    $ontologija->setGlumac($glumac);
    $ontologija->setGlumi($glumi);
    $ontologija->setNagrada($nagrada);
    $ontologija->setRodjenje($rodjenje);
    $ontologija->setZavrsio($zavrsio);
    $ontologija->setGodina($godina);
    $ontologija->setImaUloga($uloga);

    $doctrineBootstrap = Flight::entityManager();
    $em = $doctrineBootstrap->getEntityManager();

    $em->persist($ontologija);
    $em->flush();
    }

  }

});

Flight::route('GET /search/@glumac', function($glumac){

  $doctrineBootstrap = Flight::entityManager();
  $em = $doctrineBootstrap->getEntityManager();
  $repozitorij=$em->getRepository('Duvnjak\Ontologija');
  $zapisi = $repozitorij->createQueryBuilder('p')
  ->where('p.glumac LIKE :glumac')
  ->setParameter('glumac', '%'.$glumac.'%')
  ->getQuery()
  ->getResult();
  echo $doctrineBootstrap->getJson($zapisi);

});

$cl = new ClassLoader('Duvnjak', __DIR__, '/src');
$cl->register();
require_once 'bootstrap.php';
Flight::register('entityManager', 'DoctrineBootstrap');

Flight::start();
